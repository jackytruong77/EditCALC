CREATE database calculatrice CHARACTER SET 'utf8';

/* 
    Vous mettez le dossiers sql dans dans votre dossier "www"
    Vous lancez Wamp ou Mamp
    Vous faites clique GAUCHE sur le petit logo quand il est en VERT
    Vous allez dans la console MariaDB en allant sur le petit MariaDb et après vous allez pouvoir voir Console MariaDb
    Puis vous vous connecter
    Puis vous faites "SOURCE C:/wamp64/www/sql/Creation_base.sql"
*/